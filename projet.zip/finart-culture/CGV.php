<!doctype html>
<s?php session_start(); ?>
<html lang="fr">
	<head>
		<title> Finart Culture </title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="PTS2.css"/>
	</head>
	<?php include("header.php"); ?>
	<body>
	<div class="page">
		<header class="site-header"></header>

		<main class="site-content"></main>

		<footer class="site-footer"></footer>
	</div>
</body>
	<?php include("footer.php"); ?>
</html>
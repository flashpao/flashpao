<!doctype html>
<s?php session_start(); ?>
<html lang="fr">
	<head>
		<title> Finart Culture </title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="PTS2.css"/>
		
	</head>
	<?php include("header.php"); ?>
	<body>
	<?php include("banniere_accueil.php"); ?>
	<div class="page">
		<header class="site-header"></header>

		<main class="site-content"></main>

		<footer class="site-footer"></footer>
	</div>
	<?php include("footer.php"); ?>
</body>
	
</html>
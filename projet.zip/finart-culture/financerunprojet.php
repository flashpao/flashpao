<!doctype html>
<s?php session_start(); ?>
<html lang="fr">
	<head>
		<title> Finart Culture </title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="PTS2.css"/>
	</head>
	<?php include("header.php"); ?>
	<body>
	<div class="page">
		<main class="site-content">
	
	<div class="card text-center">
	<div class="card-header">
    Liste des projets actuellements disponibles
	</div>
<div class="card-body">
<div class="card-deck">
  <div class="card">
    <img src="Projet 1 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 1</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
    </div>
    <div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
  <div class="card">
    <img src="Projet 2 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 2</h5>
      <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
    </div>
	<div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
  <div class="card">
    <img src="Projet 3 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 3</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
    </div>
	<div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
</div>
<div class="card-deck">
  <div class="card">
    <img src="Projet 4 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 4</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
    </div>
    <div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
  <div class="card">
    <img src="Projet 5 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 5</h5>
      <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
    </div>
	<div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
  <div class="card">
    <img src="Projet 6 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 6</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
    </div>
	<div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
</div>
<div class="card-deck">
  <div class="card">
    <img src="Projet 7 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 7</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
    </div>
    <div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
  <div class="card">
    <img src="Projet 8 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 8</h5>
      <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
    </div>
	<div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
  <div class="card">
    <img src="Projet 9 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 9</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
    </div>
	<div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
</div>
<div class="card-deck">
  <div class="card">
    <img src="Projet 10 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 10</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
    </div>
    <div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
  <div class="card">
    <img src="Projet 11 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 11</h5>
      <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
    </div>
	<div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
  <div class="card">
    <img src="Projet 12 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 12</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
    </div>
	<div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
</div>
<div class="card-deck">
  <div class="card">
    <img src="Projet 13 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 13</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
    </div>
    <div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
  <div class="card">
    <img src="Projet 14 FC.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 14</h5>
      <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
    </div>
	<div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
  <div class="card">
    <img src="banniere_accueil.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Projet 15</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
    </div>
	<div class="card-footer">
      <a href="#" class="btn btn-primary">Financer ce projet</a>
	</div>
  </div>
</div>
</div>
	<div class="card-footer text-muted">
		<a href="démarrervotreprojet.php" class="btn btn-primary">Créer le votre ici!</a>
	  </div>
	</div>
	
		
	  
	  
	</main>
	</body>
	<?php include("footer.php"); ?>
</html>